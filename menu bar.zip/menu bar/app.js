const hamburger = document.querySelector('.hamburgher');
const navLink = document.querySelector('.link-nav');
const navLinkItem = Array.from(navLink.children);



hamburger.addEventListener('click', ()=>{
    navLink.classList.toggle('link-open');

    navLinkItem.forEach((link , i) => {
        if( link.classList=='link-move'){
            link.classList.add('link-move'); 
        }else{
            link.classList.toggle('link-move'); 

        }
        

    
    });

});